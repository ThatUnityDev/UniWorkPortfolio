// First name adn Second name app.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include "pch.h"
#include <iostream>
#include <string>
using namespace std;

int main()
{
	int i = 0;
	while (i == 0) {
		string FirstName;
		string SecondName;
		string Confirm;

		cout << "Please enter your first name: ";
		cin >> FirstName;
		cout << "Please eneter your second name: ";
		cin >> SecondName;

		if (FirstName != "" && SecondName != "") {
			cout << "Thank you for inputting your name" << endl;
			cout << "Your name is " << FirstName + SecondName << endl;
			cout << "Please confirm this by intputting Y or N" << endl;
			cin >> Confirm;
			if (Confirm == "Y") {
				cout << "Thank you" << endl;
				i++;
			}
			else if (Confirm == "N") {

			}
		}
		else if (FirstName == "") {
			cout << "Your first name has been left empty" << endl;
		}
		else if (SecondName == "") {
			cout << "Your second name has been left empty" << endl;
		}
		else {
			cout << "We have ran into an unknown error" << endl;
			cout << "Please bare with us" << endl;
			i++;
		}
	}
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
