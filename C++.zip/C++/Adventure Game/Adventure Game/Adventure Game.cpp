// Adventure Game.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include "pch.h"
#include <iostream>
#include <string>
using namespace std;

int main()
{
	int i = 0;
	int a = 0;
	int b = 0;

	string Name;
	string Confirm;

	int Points = 100;
	int Strength = 0;
	int Defense = 0;
	int Charisma = 0;
	int Health = 10;

	bool ConfirmedName = false;
	bool ConfirmedStats = false;

	while (i == 0) {
		cout << "Game has loaded" << endl;
		while (a == 0) {
			cout << "Character creator" << endl;
			if (ConfirmedName != true) {
				cout << "Please enter your name: ";
				cin >> Name;
				cout << "Please confirm that you enterd: " << Name << " by inputting Y or N" << endl;
				cin >> Confirm;
				if (Confirm == "Y") {
					cout << "Thank you" << endl;
					ConfirmedName = true;
				}
				else if (Confirm == "N") {

				}
				else {
					cout << "Sorry but an unknown error has occued" << endl;
					cout << "Please reload and try again" << endl;
				}
			}
			if (ConfirmedStats != true) {
				while (Points != 0) {
					cout << "You have: " << Points << " point remaining";
					cout << "You can spend points to increase stats";
					int SpentPoints;
					string stat;
					cout << "what stat (1,2,3) do you want to add points to" << endl;
					cout << "1. Strength: " << Strength << endl;
					cout << "2. Defense: " << Defense << endl;
					cout << "3. Charisma: " << Charisma << endl;
					cin >> stat;
					if (stat == "1") {
						cout << "How many points do you want to spend?" << endl;
						cin >> SpentPoints;
						Strength = Strength + SpentPoints;
						Points = Points - SpentPoints;
					}
					else if (stat == "2") {
						cout << "How many points do you want to spend?" << endl;
						cin >> SpentPoints;
						Defense = Defense + SpentPoints;
						Points = Points - SpentPoints;
					}
					else if (stat == "3") {
						cout << "How many points do you want to spend?" << endl;
						cin >> SpentPoints;
						Charisma = Charisma + SpentPoints;
						Points = Points - SpentPoints;
					}
					else {
						cout << "Sorry but an unknown error has occured" << endl;
						cout << "Please reload and try again" << endl;
					}
					if (Points == 0) {
						cout << "You have spent all of your points" << endl;
						cout << "Strength: " << Strength << endl;
						cout << "Defense: " << Defense << endl;
						cout << "Charisma: " << Charisma << endl;
						cout << "Please confirm these by inputting either Y or N" << endl;
						cin >> Confirm;
						if (Confirm == "Y") {
							cout << "Thank you" << endl;
							ConfirmedStats = true;
						}
						else if (Confirm == "N") {

						}
						else {
							cout << "Sorry but an unknown error has occured" << endl;
							cout << "Please reload and try again" << endl;
						}
						if (ConfirmedName == true && ConfirmedStats == true) {
							cout << "Your character has now been created" << endl;
							cout << "Name: " << Name << endl;
							cout << "Stats" << endl;
							cout << "Strength: " << Strength << endl;
							cout << "Defense: " << Defense << endl;
							cout << "Charisma: " << Charisma << endl;
							a = a + 1;
						}
						else {
							cout << "Sorry but an unknown error has occured" << endl;
							cout << "Please reload and try again" << endl;
						}
					}
				}
			}
		}
		while (b == 0) {
			cout << "Ready to begin your epic adventure!" << endl;
		}
	}
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
