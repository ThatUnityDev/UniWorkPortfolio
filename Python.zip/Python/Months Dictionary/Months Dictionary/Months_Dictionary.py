MonthConversions = {
	"Jan":"January",
	"Feb":"February",
	"Mar":"March",
	"Apr":"April",
	"May":"May",
	"Jun":"June",
	"Jul":"July",
	"Aug":"August",
	"Sep":"September",
	"Oct":"October",
	"Nov":"Novemeber",
	"Dec":"December",
}

print("My bitday is on " + MonthConversions["Nov"])
print("Christmas is on " + MonthConversions.get("Dec"))
print(MonthConversions.get("Luv", "Invalid key"))
