def W1():
      print("Well done!")
      print(" |\     ______________     /|     " )
      print(" | \   |              |   / |   " )
      print(" |  \  |              |  /  |      " )
      print(" |   \_|              |_/   |    " )
      print(" |                          |    " )
      print(" |    _                _    |     " )
      print(" |   / |              | \   |     " )
      print(" |  /  |              |  \  |     " )
      print(" | /   |______________|   \ |     " )
      print(" |/                        \|    " )
      print("YAY, you have earned a piece of candy.")








print(" ________________________________________________________")
print("/                                                        \ ")
print("|           ___________           ________               |")
print("|          |           |         |        |              |")
print("|          |           |         |        |              |")
print("|          |           |         |        |              |")
print("|          |___________|         |________|              |")
print("|                                                        |")
print("|                                                        |")
print("|                                                        |")
print("|              \_________________________/               |")
print("|                                                        |")
print("\________________________________________________________/")

print("Hello, my name is Harrison.")
name = input(str("What is your name?"))
print("It is so nice to meet you " + name)
print("I am a computer. I was created on the 22/06/2019 at 20:22.")
age = input(str("How old are you?"))
print("WOW, you are " + age + " years old.")

Math = input("Do you want to play a math game? (Y/N)")

if Math == "Y":
    print("YAY, cool. I love math games.")
    Q1 = "What is the square root of 9?"
    print("1. " + Q1)
    A1 = input()

if A1 ==3:
    W1();
