from tkinter import *

def Click():
    print("You just cicked me")

master = Tk()

Button(text="Helo Everyone").pack()


separator = Frame(height=2, bd=1, relief=SUNKEN)
separator.pack(fill=X, padx=5, pady=5)

mainloop()
