from tkinter import *

def click(Name_TextBox):
    print("Hello " + str(Name_TextBox))

Name_Label = Label(text="Name").pack()
Name_TextBox = Entry().pack()
Button_Hello = Button(text="Submit", command=click(Name_TextBox)).pack()
