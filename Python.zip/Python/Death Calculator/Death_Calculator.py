from random import randint

def Death(Num_Of_Cigs, BMI):
    if int(Num_Of_Cigs) < 25 and int(BMI) <= 99:
        Chance_Of_Death = False
    else:
        Chance_Of_Death = True
        
    return Chance_Of_Death

print("Name")
Name = input()
print("Age")
Age = input()
Questions = ["Date of birth", "Smoker", "BMI", "Gender"]
x = 0

for x in range(len(Questions)):
    Question = Questions[x]
    print(Question)
    if Question =="Date of birth":
        print("What is your date of birth")
        print("DD/MM/YYYY")
        Answer_One = str(input())
        DOB = Answer_One
    if Question == "Smoker":
        print("How many cigarettes a week do you smoke? ")
        Answer_Two = int(input())
        Num_Of_Cigs = Answer_Two
    if Question == "BMI":
        print("What is your BMI?")
        Answer_Three = float(input())
        BMI = Answer_Three
    if Question == "Gender":
        print("What is your gender?")
        Answer_Four = str(input())
        Gender = Answer_Four
        
Death(Num_Of_Cigs, BMI)
Chance = Chance_Of_Death

if Chance == True:
    Days_Left = randint(1, 9000)
else:
    Days_Left = randint(4000, 15000)

print(Chance)
print(str(Days_Left))
