def powers(base_num, pow_num):
    result = 1
    for Index in range(pow_num):
        result = result * base_num
    return result
    
print("Enter a number: ")
num1 = int(input())
print("Enter a number: ")
num2 = int(input())
print(str(num1) + " to the power of " + str(num2) + " is: " + str(powers(num1, num2)))