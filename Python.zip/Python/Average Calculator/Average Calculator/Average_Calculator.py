def AVERAGE():
    result = Num1 / Num2
    print(result)

try:
    Num1 = float(input("Please enter a number: "))
    Num2 = float(input("Please enter a number: "))
    AVERAGE()
except ValueError:
    print("Invalid data entered")
