Balance = 0.0
Withdrawn = 0.0
x = 0

while x == 0:
    z = 0
    Complete_Withdrawn = Withdrawn
    print("Are you looking to, \nDeposit \nWidthdraw \nCheck balance \nCheck withdrawn amount")
    Decision = input("")
    while z == 0:
        print("Are you looking to, \nDeposit \nWithdraw \nCheck balance \nCheck withdrawn amount")
        Decision = input("")
        if Decision == "Deposit":
            print("How much are you looking to deposit?")
            Deposit_Amount = float(input(""))
            Balance = Balance + Deposit_Amount
            z = z + 1
        elif Decision == "Withdraw":
            print("How much are you looking to deposit?")
            Withdraw_Amount = float(input(""))
            Withdrawn = Withdrawn + Withdrawn_Amount
            z = z + 1
        elif Decision == "Check balance":
            print(str(Balance))
            z = z + 1
        elif Decision == "Check withdrawn amount":
            print(str(Complete_Withdrawn))
            z = z + 1
        else:
            print("Error: Could not find command \nPlease try again")

