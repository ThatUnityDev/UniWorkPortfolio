def PRINT():
    print("Your friends are: ")
    for Index in range(len(Friends)):
        print(Friends[Index])
    return

def COPY():
    Friends.copy()
    print("The list has been successfully copied.")
    return

def SORT():
    Friends.sort()
    print("The list has successfully been sorted.")
    print(Friends)
    return

def REVERSE():
    print("The list has successfully been reversed.")
    for Index in range(len(Friends)):
        print(Friends.reverse()[Index])
    return

def COUNT():
    print("Who are you looking for?")
    Person = input()
    Friends.count(Person)
    return

def CLEAR():
    Friends.clear()
    print("The lsit has successfully been cleared")
    return

def ADD():
    print("Who are you looking to add to the list?")
    Person = input()
    Friends.append(Person)
    return

def REMOVE():
    print("Who are you looking to remove from the list?")
    Person = input()
    Friends.count(Person)
    return

def INA():
    print("Who are you looking to add to the list?")
    Person = input()
    print("Enter a number")
    Index = input()
    Friends.insert(int(Index), Person)
    return

def REPLACE():
    print("Who are you looking to replace?")
    Person = input()
    print("Who do you want to add?")
    Add = input()
    Friends.replace(Person, Add)
    print("This has bee successfully done.")
    return

def INDEX():
    print("Who are you looking FOR?")
    Person = input()
    Index = Friends(Person.index)
    print("Index" + str(Index))
    return


Friends = ["Harrison", "John", "Adam", "Smith", "Johns",]
Tools = ["Print", "Copy", "Sort", "Reverse", "Count", "Clear", "Add", "Remove",  "Indent and Add", "Search", "Replace", "Index"]

print("Hello user. Welcome to your advanced list manipulating tool.")
print("This tool has a wide rnage of tools. These tools include: ")

for Index in range(len(Tools)):
	print(Tools[Index])

print("If you wish to exit then enter: 'Q'")
print("Which tool do you want to use?")
Decision = input()

if Decision == "Print":
    Choice1 = input("You sure you want to PRINT the list? (Y/N)")
    if Choice1 == "Y":
        PRINT()
    else:
        SystemExit
if Decision == "Copy":
    Choice2 = input("You sure you want to COPY the list? (Y/N)")
    if Choice2 == "Y":
        COPY()
    else:
        SystemExit
if Decision == "Sort":
    Choice3 = input("You sure you want to SORT the list? (Y/N)")
    if Choice3 == "Y":
        SORT()
    else:
        SystemExit
if Decision == "Reverse":
    Choice4 = input("You sure you want to REVERSE the list? (Y/N)")
    if Choice4 == "Y":
        REVERSE()
    else:
        SystemExit
if Decision == "Count":
    Choice5 = input("You sure you want to COUNT the list? (Y/N)")
    if Choice5 == "Y":
        COUNT()
    else:
        SystemExit
if Decision == "Clear":
    Choice6 = input("You sure you want to CLEAR the list? (Y/N)")
    if Choice6 == "Y":
        CLEAR()
    else:
        SystemExit
if Decision == "Add":
    Choice7 = input("You sure you want to ADD the list? (Y/N)")
    if Choice7 == "Y":
        ADD()
    else:
        SystemExit
if Decision == "Remove":
    Choice8 = input("You sure you want to REMOVE the list? (Y/N)")
    if Choice8 == "Y":
        REMOVE()
    else:
        SystemExit
if Decision == "Indent and Add":
    Choice9 = input("You sure you want to INDENT & ADD the list? (Y/N)")
    if Choice9 == "Y":
        INA()
    else:
        SystemExit
if Decision == "Replace":
    Choice10 = input("You sure you want to REPLACE the list? (Y/N)")
    if Choic10 == "Y":
        REPLACE()
    else:
        SystemExit
if Decision == "Index":
    Choice11 = input("You sure you want to INDEX the list? (Y/N)")
    if Choice11 == "Y":
        INDEX()
    else:
        SystemExit
if Decision == "Q":
    SystemExit