x = 0
y = 0
Gathered_Data = []
Data = open("Data.csv", "w")

while x == 0:
    while y == 0:
        print("Please enter your firstname")
        First_Name = str(input(""))
        print("Please input your second name")
        Second_Name = str(input(""))
        print("Please input your age")
        Age = int(input(""))
        print("First name: " + First_Name + "\nSecond name: " + Second_Name + "\nAge: " + str(Age))
        print("Is the data above correct (Y/N)")
        Correct = input()
        if Correct == "Y":
            y = y + 1
            Gathered_Data.append(str(First_Name))
            Gathered_Data.append(str(Second_Name))
            Gathered_Data.append(str(Age))
            for i in range(len(Gathered_Data)):
                Data.write(Gathered_Data[i] + " ")
            Data.close()
        else:
            print("Please re-enter your data")
