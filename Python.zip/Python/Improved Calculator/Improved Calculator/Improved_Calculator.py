def ADD():
    Num1 = float(input("Please enter a number: "))
    Num2 = float(input("Please enter another number: "))

    result = float(Num1) + float(Num2)

    print(result)

def MUL():
    Num1 = float(input("Please enter a number: "))
    Num2 = float(input("Please enter another number: "))

    result = float(Num1) * float(Num2)

    print(result)

def SUB():
    Num1 = float(input("Please enter a number: "))
    Num2 = float(input("Please enter another number: "))

    result = float(Num1) - float(Num2)

    print(result)

def DIV():
    Num1 = float(input("Please enter a number: "))
    Num2 = float(input("Please enter another number: "))

    result = float(Num1) / float(Num2)

    print(result)

print("Welcoem to your advanced calulcator")
print("With this calculator yo can multiply,divide,add and subtract a pair of two numbers")
print("Answer = number A (+,-,*,/) number B")

Decision = input("What function shall you be uisng? (A,M,S,D)")

if Decision == "A":
    ADD()

if Decision == "M":
    MUL()

if Decision == "S":
    SUB()

if Decision == "D":
    DIV()