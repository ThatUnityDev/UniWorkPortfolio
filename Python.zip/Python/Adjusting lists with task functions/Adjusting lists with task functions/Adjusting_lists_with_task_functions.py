def ADD():
    Person = input("What name would you like to add?")
    Friends.append(Person)
    print("They have been added to the list succesfully")
    print("Your current friends:")
    print(Friends)

def DEL():
    Person = input("Who do you want to delete from the list?")
    Friends.remove(Person)
    print("That person has succesfully been removed from the list")
    print("Your current friends:")
    print(Friends)

def SORT():
    Friends.sort()
    print("The list has been sorted")
    print("Your current friends:")
    print(Friends)
          
def CHECK():
    Person = input("Who are you looking for?")
    Amount = str(Friends.count(Person))
    print("That name appears: " + Amount + " times in this list.")

def COPY():
    Friends.copy()
    print("This lsit has been successfully copied.")

def CLEAR(Choice):
    if Choice == "Y":
        Friends.clear()
        print("This list has successfully been deleted")
    else:   
        SystemExit

def QUIT():
    print("Goodbye!")
    SystemExit

Friends = [("Dave"), ("John"), ("Adam"),]
print("Your current friends:")
print(Friends)

print("What would you like to do to the list? (Add,Delete,Sort,Check,Copy or Clear)")
print("If you wish to quit then enter 'QUIT'")
Decision = input()

if Decision ==  "":
    print("Sorry but you have not made a decision. If you wish to quit then please enter 'QUIT'. Thank you!")

if Decision ==  "Add":
    ADD()
    
if Decision ==  "Delete":
    DEL()

if Decision ==  "Sort":
    SORT()

if Decision ==  "Check":
    CHECK()

if Decision ==  "Copy":
    COPY()

if Decision == "Clear":
    CLEAR(input("Are you sure you want to clear this list? (Y/N)"))

if Decision ==  "QUIT":
    QUIT()