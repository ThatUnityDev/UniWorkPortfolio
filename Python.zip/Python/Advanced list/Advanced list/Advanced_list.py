Friends = ["Harrison", "John", "Josh", "Adam", "Ben", "Bob", "Mike"]
print("Your friends are:")
for Index in range(len(Friends)):
    print(Friends[Index])
