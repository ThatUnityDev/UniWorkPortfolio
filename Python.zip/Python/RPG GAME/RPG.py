i = 0
MyFriends = []
MyAttack = ""
MyDefense = ""

while i == 0:
    print("Welcome to the character creator")
    MyName = str(input("What is your characters name:\n")
    MyAge = int(input("What is your characters age:\n"))
