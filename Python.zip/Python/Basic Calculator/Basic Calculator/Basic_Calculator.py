num1 = input("Please enter a number: ")
num2 = input("Please enter another number: ")

result = float(num1) + float(num2) 

print(result)
