from math import *

print("     /|")
print("    / |")
print("   /  |")
print("  /   |")
print(" /____|")

print("Pythagares Theorem")
print("h^2 = a^2 + b^2") 

a = input("Please enter a number: ")
b = input("Please enter a number: ")
h = float(float(a) * float(a)) + float(float(b) * float(b))
answer = str(sqrt(h))
print("H = " + answer)