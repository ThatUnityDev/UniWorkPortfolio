def ADD(Num1, Num2, Result):
    Result = Num1 + Num2
    return Result
def SUB(Num1, Num2, Result):
    Result = Num1 + Num2
    return Result
def DIV(Num1, Num2, Result):
    Result = Num1 + Num2
    return Result
def MUL(Num1, Num2, Result):
    Result = Num1 + Num2
    return Result
