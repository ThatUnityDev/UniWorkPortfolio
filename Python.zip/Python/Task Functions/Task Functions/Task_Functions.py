def sayhi():
    print("Hello World!")

sayhi()