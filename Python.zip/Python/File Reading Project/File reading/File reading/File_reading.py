File = open("File.csv", "r")
print(File.read())
