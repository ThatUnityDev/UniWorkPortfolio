def Harrison():
    print("Hello creator")

Name = input("Please enter your name")
Age = input("Please enter your age")
Hair_Colour = input("Please enter your hair colour")
Eye_Colour = input("Please enter your eye colour")
Details = []
Details.insert(0, Name)
Details.insert(1, Age)
Details.insert(2, Hair_Colour)
Details.insert(3, Eye_Colour)
print(Details)
Check = Details.count("Harrison Gwatkin")
print(Check)

if Name == "Harrison Gwatkin" and Check == 1:
    Harrison()