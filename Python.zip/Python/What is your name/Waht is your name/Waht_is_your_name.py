Name = str(input("What is your name?")()
Age = int(input("How old are you?"))
print("Hello " + Name + "!")
print("You are " + Age + " years old.")
