Num1 = input("Which times tables do you want to learn?")
i = 1

while i <= int(Num1):
    result = int(Num1) * i
    print(result)
    i += 1
