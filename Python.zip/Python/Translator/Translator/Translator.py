def Translate(phrase):
    Translation = ""
    for Letter in phrase:
        if Letter in "AEIOUaeiou":
            Translation = Translation + "g"
        else:
            Translation = Translation + Letter
    return Translation

print(Translate(input("Enter a phrase")))