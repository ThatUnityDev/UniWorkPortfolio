Friends = ["Bob", "John", "Harry", "Josh", "Jones", "Karen"]

""" This shall print the entire list """
print(Friends)

""" This shall print the name with an index of '0' in the list """
print(Friends[0])

""" This shall print the name with an index of '1' in the list and everything after it """
print(Friends[1:])

""" This shall print the name with and index of '1' in the list and everything after it up until index '3'. This does not include index '3' """
print(Friends[1:3])