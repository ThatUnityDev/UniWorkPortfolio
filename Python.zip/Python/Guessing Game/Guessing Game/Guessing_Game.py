Secret_Word = "Harrison"
Guess = ""
Tries = 0
Max_Guesses = 3

while Guess != Secret_Word and Tries < 3:
    Guess = input("Try to guess the secret word")
    Tries += 1
    Max_Guesses -= 1
    print("You have: " + str(Max_Guesses) + " gueses remaing")

if Tries == 3:
    print("Oops you ran out of guesses")
else:
    print("Well done!")


