Num_Of_Products = int(input("How many items are you purchasing: "))
Total = 0
Products = []
x = 0

for x in range(Num_Of_Products):
    Product = input("Please enter the name of the product: ")
    Price = float(input("Please enter the price of this product: "))
    Products.append(Product)
    Total = float(Total) + float(Price)
    x = x + 1

print("Basket: " + str(Products))
print("Total: £" + str(Total))
    
