Friends = ["Kevin", "Bob", "Karen", "Jim", "Oscar"]
Lucky_Numbers = [4, 18, 27, 23, 53]

""" Adding the lucky numbers list to the friends list """
print(Friends.extend(Lucky_Numbers))

""" Adding Karl to the friends list """
print(Friends.append("Karl"))

""" Inserting Karl into the list at index 2 """
print(Friends.insert(2, "Karl"))

""" Removing the first Karl from the list """
print(Friends.remove("Karl"))

""" Checking how many times a friend pops up in the list """
print(Friends.count("Kevin"))

""" Sorting the lucky numbers list into accending order """
print(Lucky_Numbers.sort())

print("The Original Lists")
print(Lucky_Numbers)
print(Friends)