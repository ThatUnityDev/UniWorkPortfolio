import random
from math import *

Troops = 10000000
Total_Troops = Troops
Political_Support = 100
War_Support = 0
Countries = [
"Afghanistan",
"Albania",
"Algeria",
"Andorra",
"Angola",
"Antigua",
"Argentina",
"Armenia",
"Australia",
"Austria",
"Azerbaijan",
"Bahamas",
"Bahrain",
"Bangladesh",
"Barbados",
"Belarus",
"Belgium",
"Belize",
"Benin",
"Bhutan",
"Bolivia",
"Bosnia",
"Botswana",
"Brazil",
"Brunei",
"Bulgaria",
"Burkina Faso",
"Burundi",
"Cabo Verde",
"Cambodia",
"Cameroon",
"Canada",
"Central African Republic",
"Chad",
"Chile",
"China",
"Colombia",
"Comoros",
"Congo",
"Costa Rica",
"Croatia",
"Cuba",
"Cyprus",
"Czechia",
"Denmark",
"Djibouti",
"Dominica",
"Dominican Republic",
"Ecuador",
"Egypt",
"El Salvador",
"Equatorial Guinea",
"Eritrea",
"Estonia",
"Eswatini",
"Ethiopia",
"Fiji",
"Finland",
"France",
"Gabon",
"Gambia",
"Georgia",
"Ghana",
"Greece",
"Grenada",
"Guatemala",
"Guinea",
"Guinea-Bissau",
"Guyana",
"Haiti",
"Honduras",
"Hungary",
"Iceland",
"India",
"Indonesia",
"Iran",
"Iraq",
"Ireland",
"Israel",
"Italy",
"Jamaica",
"Japan",
"Jordan",
"Kazakhstan",
"Kenya",
"Kiribati",
"Kosovo",
"Kuwait",
"Kyrgyzstan",
"Laos",
"Latvia",
"Lebanon",
"Lesotho",
"Liberia",
"Libya",
"Liechtenstein",
"Lithuania",
"Luxembourg",
"Madagascar",
"Malawi",
"Malaysia",
"Maldives",
"Mali",
"Malta",
"Marshall Islands",
"Mauritania",
"Mauritius",
"Mexico",
"Micronesia",
"Moldova",
"Monaco",
"Mongolia",
"Montenegro",
"Morocco",
"Mozambique",
"Myanmar",
"Namibia",
"Nauru",
"Nepal",
"Netherlands",
"New Zealand",
"Nicaragua",
"Niger",
"Nigeria",
"North Korea",
"North Macedonia",
"Norway",
"Oman",
"Pakistan",
"Palau",
"Palestine",
"Panama",
"Papua New Guinea",
"Paraguay",
"Peru",
"Philippines",
"Poland",
"Portugal",
"Qatar",
"Romania",
"Russia",
"Rwanda",
"Saint Kitts",
"Saint Lucia",
"Saint Vincent",
"Samoa",
"San Marino",
"Sao Tome",
"Saudi Arabia",
"Senegal",
"Serbia",
"Seychelles",
"Sierra Leone",
"Singapore",
"Slovakia",
"Slovenia",
"Solomon Islands",
"Somalia",
"South Africa",
"South Korea",
"South Sudan",
"Spain",
"Sri Lanka",
"Sudan",
"Suriname",
"Sweden",
"Switzerland",
"Syria",
"Taiwan",
"Tajikistan",
"Tanzania",
"Thailand",
"Timor-Leste",
"Togo",
"Tonga",
"Trinidad",
"Tunisia",
"Turkey",
"Turkmenistan",
"Tuvalu",
"Uganda",
"Ukraine",
"United Arab Emirates",
"United Kingdom",
"United States of America",
"Uruguay",
"Uzbekistan",
"Vanuatu",
"Vatican City",
"Venezuela",
"Vietnam",
"Yemen",
"Zambia",
"Zimbabwe"
]
Invaded_Countries = []
Supplies = 20000000
Total_Casualties = 0
x = 0
Victory = False
Game_Victory = False
y = 0
z = 0

while x == 0:
    for y in range(len(Countries)):
        print(Countries[y])
    Choice = str(input("Please select a country from the list: "))
    if Choice == "":
        print("You have not selected a country to invade.")
    else:
        if Invaded_Countries.count(Choice) == 1:
            print("You have already invaded this country")
        else:
            Casualties = random.randint(0, 100000)
            if Casualties >= 60000:
                Victory = False
            else:
                Victory = True
            if Victory == False:
                Troops = Troops - Casualties
                Total_Casualties = Total_Casualties + Casualties
                Supplies = Supplies - (ceil(Casualties/2))
                War_Support = War_Support + 1
                Political_Support = Political_Support - 10
            else:
                Troops = Troops - Casualties
                Total_Casualties = Total_Casualties + Casualties
                Supplies = Supplies - (ceil(Casualties/2))
                War_Support = War_Support + 10
                Political_Support = Political_Support + 10
                Countries.remove(Choice)
                Invaded_Countries.append(Choice)
            for z in range(int(War_Support/10)):
                Troops = Troops + 1000
                Total_Troops = Troops
            if len(Countries) == 0:
                Game_Victory = True
                x = x + 1
            elif Political_Support == 0 or Troops == 0 or Supplies == 0:
                Game_Victory = False
                x = x + 1

Stat_One = (Total_Casualties / Total_Troops) * 100 
Stat_Two = Political_Support
Stat_Three = Total_Casualties
Stat_Four = Total_Troops
Stat_Five = War_Support
Stat_Six = len(Invaded_Countries)
if Game_Victory == True:
    print("Great leader you have been victorious")
    print("Game Stats")
    print("You lost " + str(Stat_One) + "% of your armed forced throughout this game\n Your Political support stood at: " + str(Stat_Two) + "\n You lost: " + str(Stat_Three) + " troops througout this game\n You had a total of: " + str(Stat_Four) + " troops\n You had a total war support of: " + str(Stat_Five) + " throughout this game\n You invaded " + str(Stat_Six) + " countires throughout this game.")
    input("")
else:
    print("Game Over")
    print("You have sadly lost due to a lack of Political support, troops and supplies")
    input("")
