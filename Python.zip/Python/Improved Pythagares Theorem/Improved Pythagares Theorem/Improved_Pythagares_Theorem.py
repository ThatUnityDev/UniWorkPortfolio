from math import*

def H():
    print("When you are done enter 0 to quit")
    print("You are trying to calculate H")
    a = input("Please enter a number for A: ")
    if a == "0":
        SystemExit
    else:
        b = input("Please enter a number for B: ")
        h = float(float(a) * float(a)) + float(float(b) * float(b))
        answer = str(sqrt(h))
        print("H = " + answer)
    
def A():
    print("When you are done enter 0 to quit")
    print("You are trying to calculate A")
    h = input("Please enter a number for H: ")
    if h == "0":
       SystemExit
    else:
        b = input("Please enter a number for B: ")
        a = float(float(h) * float(h)) - float(float(b) * float(b))
        answer = str(sqrt(a))
        print("A = " + answer)



def B():
    print("When you are done enter 0 to quit")
    print("You are trying to calculate B")
    h = input("Please enter a number for H: ")
    if h == "0":
        SystemExit
    else:
        a = input("Please enter a number for A: ")
        b = float(float(h) * float(h)) - float(float(a) * float(a))
        answer = str(sqrt(b))
        print("B = " + answer)

print("Pythagares Theorem")
print("h^2 = a^2 + b^2") 
print("     /|   ")
print("    / |   ")
print(" h /  | b ")
print("  /   |   ")
print(" /____|   ")
print("   a      ")

Decision = input("What are you trying to calculate? (h,a,b)")
if Decision == "h":
    H()


if Decision == "a":
    A()

if Decision == "b":
    B()
