print("Hello world");
print("Welcome to the future");
print("78");

if print == "Hello world":
print("welcome");
else:
print("NO!!!");

Name = (input(print("What is your name?"));
